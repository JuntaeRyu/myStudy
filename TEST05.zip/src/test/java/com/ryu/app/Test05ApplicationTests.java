package com.ryu.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
